HOW TO PUT THIS SITE ON GOOGLE

1. Upload this whole folder to a static host (Netlify Drop at app.netlify.com/drop, Cloudflare Pages, or GitHub Pages). You get a free subdomain such as yourname.netlify.app.
2. Replace YOUR-DOMAIN in sitemap.xml and robots.txt with your real address (for example malani-equestrian.netlify.app), then upload again.
3. Open Google Search Console, add the site, and submit https://YOUR-DOMAIN/sitemap.xml.
4. Add the website address to the academy's Google Business Profile.
5. Optional: buy your own domain and connect it in the host's domain settings.
