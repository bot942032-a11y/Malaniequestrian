
(function () {
  var $ = function (id) { return document.getElementById(id); };
  var NS = 'http://www.w3.org/2000/svg';
  var rupee = function (n) { return '₹' + n.toLocaleString('en-IN'); };

  /* ---------- arena ---------- */
  var YOFF = 620; // y of A; 10 units per metre
  var MK = {
    A: { side: 'Entry end', m: 0, x: 140, info: 'Short end of the arena. Riders enter here at the start of a test.' },
    C: { side: 'Far end', m: 60, x: 140, info: 'Opposite short end. The judge usually sits here.' },
    K: { side: 'Left long side', m: 6, x: 40 }, V: { side: 'Left long side', m: 18, x: 40 }, E: { side: 'Left long side', m: 30, x: 40, info: 'Middle of the left long side.' },
    S: { side: 'Left long side', m: 42, x: 40 }, H: { side: 'Left long side', m: 54, x: 40 },
    F: { side: 'Right long side', m: 6, x: 240 }, P: { side: 'Right long side', m: 18, x: 240 }, B: { side: 'Right long side', m: 30, x: 240, info: 'Middle of the right long side.' },
    R: { side: 'Right long side', m: 42, x: 240 }, M: { side: 'Right long side', m: 54, x: 240 },
    D: { side: 'Centre line', m: 6, x: 140 }, L: { side: 'Centre line', m: 18, x: 140 }, X: { side: 'Centre line', m: 30, x: 140, info: 'The exact centre of the arena.' },
    I: { side: 'Centre line', m: 42, x: 140 }, G: { side: 'Centre line', m: 54, x: 140 }
  };
  var ORDER = ['A', 'K', 'V', 'E', 'S', 'H', 'C', 'M', 'R', 'B', 'P', 'F', 'D', 'L', 'X', 'I', 'G'];
  function el(tag, attrs, text) {
    var n = document.createElementNS(NS, tag);
    for (var k in attrs) n.setAttribute(k, attrs[k]);
    if (text != null) n.textContent = text;
    return n;
  }
  function labelPos(k) {
    var d = MK[k], y = YOFF - d.m * 10;
    if (k === 'A') return { x: 140, y: 640 };
    if (k === 'C') return { x: 140, y: 8 };
    if (d.side === 'Left long side') return { x: 20, y: y };
    if (d.side === 'Right long side') return { x: 260, y: y };
    return { x: 154, y: y - 12 };
  }
  function drawArena(host, opts) {
    host.innerHTML = '';
    var svg = el('svg', { viewBox: '0 0 280 650', role: 'img', 'aria-label': '20 by 60 metre dressage arena with letter markers' });
    svg.appendChild(el('rect', { 'class': 'a-fill', x: 40, y: 20, width: 200, height: 600 }));
    svg.appendChild(el('rect', { 'class': 'a-line', x: 40, y: 20, width: 200, height: 600 }));
    svg.appendChild(el('line', { 'class': 'a-mid', x1: 140, y1: 20, x2: 140, y2: 620 }));
    if (opts.path) svg.appendChild(el('path', { 'class': 'a-path', d: 'M140 620 L140 330 C 140 250, 220 250, 220 180 C 220 90, 60 90, 60 180 C 60 250, 140 250, 140 330 L140 20' }));
    ['D', 'L', 'X', 'I', 'G'].forEach(function (k) { svg.appendChild(el('circle', { 'class': 'a-dot', cx: 140, cy: YOFF - MK[k].m * 10, r: 3.5 })); });
    ORDER.forEach(function (k) {
      var p = labelPos(k), small = MK[k].side === 'Centre line';
      var g = el('g', { 'class': 'mk' + (opts.sel === k ? ' on' : ''), 'data-k': k });
      if (opts.interactive) { g.setAttribute('tabindex', '0'); g.setAttribute('role', 'button'); g.setAttribute('aria-label', 'Marker ' + k); }
      if (opts.sel === k) {
        var ry = YOFF - MK[k].m * 10;
        g.appendChild(el('circle', { 'class': 'ring', cx: MK[k].x, cy: ry, r: 9 }));
      }
      g.appendChild(el('circle', { 'class': 'hit', cx: p.x, cy: p.y, r: 18 }));
      g.appendChild(el('text', { 'class': 'a-ltr' + (small ? ' small' : ''), x: p.x, y: p.y, 'text-anchor': 'middle', 'dominant-baseline': 'middle' }, k));
      svg.appendChild(g);
    });
    host.appendChild(svg);
    var cap = document.createElement('figcaption');
    cap.textContent = opts.caption;
    host.appendChild(cap);
  }
  if ($('arena-hero')) drawArena($('arena-hero'), { path: true, caption: 'A standard 20 × 60 m dressage arena, drawn to scale. Riders enter at A.' });

  var sel = 'E';
  function renderExplorer() {
    drawArena($('arena-explorer'), { interactive: true, sel: sel, caption: 'Drawn to scale. Tap any letter.' });
    var d = MK[sel];
    $('ex-letter').textContent = sel;
    $('ex-where').textContent = d.side + (d.info ? '. ' + d.info : '.');
    $('ex-dist').textContent = d.m + ' m from A · ' + (60 - d.m) + ' m from C';
    var chips = $('ex-chips'); chips.innerHTML = '';
    ORDER.forEach(function (k) {
      var b = document.createElement('button');
      b.type = 'button'; b.textContent = k; b.setAttribute('aria-pressed', k === sel ? 'true' : 'false');
      b.addEventListener('click', function () { sel = k; renderExplorer(); });
      chips.appendChild(b);
    });
  }
  if ($('arena-explorer')) $('arena-explorer').addEventListener('click', function (e) {
    var g = e.target.closest ? e.target.closest('.mk') : null;
    if (g) { sel = g.getAttribute('data-k'); renderExplorer(); }
  });
  if ($('arena-explorer')) $('arena-explorer').addEventListener('keydown', function (e) {
    var g = e.target.closest ? e.target.closest('.mk') : null;
    if (g && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); sel = g.getAttribute('data-k'); renderExplorer(); }
  });
  if ($('arena-explorer')) renderExplorer();

  /* ---------- discipline tabs ---------- */
  var DISC = [
    { id: 'dressage', name: 'Dressage', unit: 'Arena work · 20 × 60 m', body: ['Dressage is ridden in the arena you can explore above, with every movement tied to a letter. Judges mark the harmony, accuracy and control of the horse and rider together.', 'The academy coaches riders for national-level dressage events.'] },
    { id: 'jump', name: 'Show Jumping', unit: 'Course work · faults and time', body: ['Show jumping is a course of fences ridden for clear rounds, with faults and time counting against you. It rewards a steady rhythm, a good line and calm control.', 'Coaching here is aimed at riders heading to national-level events.'] },
    { id: 'xc', name: 'Cross-country', unit: 'Outdoor riding', body: ['Cross-country takes riding out of the arena and across open ground and natural obstacles. It builds boldness and judgement as well as fitness.', 'The academy offers outdoor cross-country riding alongside its arena disciplines.'] }
  ];
  var curTab = 0;
  function renderTabs() {
    var tabs = $('disc-tabs'); tabs.innerHTML = '';
    DISC.forEach(function (d, i) {
      var b = document.createElement('button');
      b.type = 'button'; b.setAttribute('role', 'tab'); b.id = 'tab-' + d.id;
      b.setAttribute('aria-selected', i === curTab ? 'true' : 'false');
      b.textContent = d.name;
      b.addEventListener('click', function () { curTab = i; renderTabs(); });
      tabs.appendChild(b);
    });
    var d = DISC[curTab], p = $('disc-panel');
    p.setAttribute('aria-labelledby', 'tab-' + d.id);
    p.innerHTML = '<p class="mono unit"></p>' + d.body.map(function () { return '<p></p>'; }).join('');
    p.firstChild.textContent = d.unit;
    var ps = p.querySelectorAll('p:not(.unit)');
    d.body.forEach(function (t, i) { ps[i].textContent = t; });
  }
  if ($('disc-tabs')) renderTabs();

  /* ---------- fee calculator ---------- */
  var RATE = { regular: 500, advanced: 1000 }, level = 'regular';
  var range = $('classes') || document.createElement('input');
  function calc() {
    var n = parseInt(range.value, 10) || 0, r = RATE[level];
    $('classes-out').textContent = n;
    $('total').textContent = rupee(n * r);
    $('line').textContent = n + ' ' + level + ' class' + (n === 1 ? '' : 'es') + ' × ' + rupee(r);
    $('cmp-reg').textContent = rupee(n * RATE.regular);
    $('cmp-adv').textContent = rupee(n * RATE.advanced);
    $('lvl-reg').setAttribute('aria-pressed', level === 'regular');
    $('lvl-adv').setAttribute('aria-pressed', level === 'advanced');
  }
  var hasCalc = !!$('classes');
  if (hasCalc) {
  range.addEventListener('input', calc);
  $('lvl-reg').addEventListener('click', function () { level = 'regular'; calc(); });
  $('lvl-adv').addEventListener('click', function () { level = 'advanced'; calc(); });
  [[4, '4 a month'], [8, '8 a month'], [12, '12 a month'], [20, '20 a month']].forEach(function (q) {
    var b = document.createElement('button'); b.type = 'button'; b.textContent = q[1];
    b.addEventListener('click', function () { range.value = q[0]; calc(); });
    $('quick').appendChild(b);
  });
  calc();
  }

  /* ---------- countdown ---------- */
  var START = new Date(2026, 10, 3, 0, 0, 0), END = new Date(2026, 10, 5, 0, 0, 0);
  function pad(n) { return n < 10 ? '0' + n : '' + n; }
  function tick() {
    var now = new Date(), diff = START - now;
    var home = $('count-home') || document.createElement('i'), status = $('status') || document.createElement('i');
    var cs = ['c-d','c-h','c-m','c-s'].map(function (i) { return $(i) || document.createElement('i'); });
    if (now >= END) {
      home.textContent = 'The 2026 qualifier has finished';
      status.textContent = 'The 2026 qualifier has finished';
      cs.forEach(function (n) { n.textContent = '00'; });
      return;
    }
    if (diff <= 0) {
      home.textContent = 'Under way now'; status.textContent = 'Under way now at the academy';
      cs.forEach(function (n) { n.textContent = '00'; });
      return;
    }
    var s = Math.floor(diff / 1000), d = Math.floor(s / 86400); s -= d * 86400;
    var h = Math.floor(s / 3600); s -= h * 3600; var m = Math.floor(s / 60); s -= m * 60;
    cs[0].textContent = d; cs[1].textContent = pad(h); cs[2].textContent = pad(m); cs[3].textContent = pad(s);
    home.textContent = d + (d === 1 ? ' day' : ' days') + ' to go';
    status.textContent = 'Day one starts on Tuesday 3 November';
  }
  setInterval(tick, 1000);

  /* ---------- enquiry composer ---------- */
  var EMAIL = 'malaniequestrianacademy@gmail.com';
  function compose() {
    var name = $('f-name').value.trim() || '[your name]';
    var lvl = $('f-level').value === 'advanced' ? 'advanced class (₹1,000)' : 'regular class (₹500)';
    var disc = $('f-disc').value;
    var when = $('f-when').value.trim();
    var t = 'Hello Malani Equestrian Sports Academy,\n\nMy name is ' + name + '. I would like to book a ' + lvl + ', and I am interested in ' + (disc === 'Not sure yet' ? 'finding out which discipline suits me' : disc.toLowerCase()) + '.';
    if (when) t += ' My preferred days or times: ' + when + '.';
    t += '\n\nPlease let me know the available class timings.\n\nThank you,\n' + name;
    $('f-msg').value = t;
    $('f-mail').setAttribute('href', 'mailto:' + EMAIL + '?subject=' + encodeURIComponent('Class enquiry') + '&body=' + encodeURIComponent(t));
  }
  if ($('enq')) {
  ['f-name', 'f-level', 'f-disc', 'f-when'].forEach(function (i) { $(i).addEventListener('input', compose); $(i).addEventListener('change', compose); });
  $('enq').addEventListener('submit', function (e) { e.preventDefault(); });
  compose();
  }

  /* ---------- copy buttons ---------- */
  function copyText(text, btn, node, idle) {
    var done = function () { btn.textContent = 'Copied'; setTimeout(function () { btn.textContent = idle; }, 1600); };
    var fallback = function () {
      try {
        if (node.select) node.select(); else { var r = document.createRange(); r.selectNodeContents(node); var s = window.getSelection(); s.removeAllRanges(); s.addRange(r); }
      } catch (e) {}
      btn.textContent = 'Selected'; setTimeout(function () { btn.textContent = idle; }, 1600);
    };
    try { navigator.clipboard.writeText(text).then(done, fallback); } catch (e) { fallback(); }
  }
  Array.prototype.forEach.call(document.querySelectorAll('.copy'), function (btn) {
    btn.addEventListener('click', function () { var n = $(btn.getAttribute('data-target')); copyText(n.textContent.trim(), btn, n, 'Copy'); });
  });
  if ($('f-copy')) $('f-copy').addEventListener('click', function () { copyText($('f-msg').value, $('f-copy'), $('f-msg'), 'Copy message'); });

  /* ---------- start ---------- */
  tick();
})();
